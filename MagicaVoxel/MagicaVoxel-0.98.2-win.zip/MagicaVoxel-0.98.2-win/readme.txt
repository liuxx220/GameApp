[MagicaVoxel : 8-bit Voxel Editor & Renderer]
================================
date    : 4/1/2017

version : 0.98.2

os      : Win32, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
@marcoapc_art : anim/horse, deer

@aronegal : anim/T-Rex

@magicfunstore : palette/pal2.png
